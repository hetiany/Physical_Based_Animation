#include "WorldManager.h"
#include <GL/glut.h>


void WorldManager::Add_PlateGenerator(PlateGenerator* plate_gen){
	generators.push_back(plate_gen);
}
void WorldManager::Add_ExplosionGenerator(ExplosionGenerator* explosion_gen){
	exp_generators.push_back(explosion_gen);
}

void WorldManager::Update(double timeStep){
	std::vector<Generator*>::iterator it = generators.begin();
	
	while(it != generators.end()){
		if((*it)->state == DEAD)
				it =  generators.erase(it);
		else{
			(*it)-> Update(timeStep);
			it++;
		}
	}


	it = exp_generators.begin();
	while(it != exp_generators.end()){
		if((*it)->state == DEAD)
				it =  exp_generators.erase(it);
		else{
			(*it)-> Update(timeStep);
			it++;
		}
	}

}

void WorldManager::Draw(){
	for(int i = 0;i < generators.size();i++){
		generators[i]->Draw();
	}
	for(int i = 0;i < exp_generators.size();i++){
		exp_generators[i]->Draw();
	}

}