#include "Generator.h"
#include "gauss.h"
#include <math.h>
#include <GL/glut.h>


/***** Plate Generator *******/    

PlateGenerator::PlateGenerator(double r,int Count, bool rotate): 
Generator(),
radius(r),
count(Count){
	double start_time = 0;
	double time_interval = -0.4;
	double angle = 0;
	double angle_factor = 2*PI/count;
	double vel_scalar = gauss(0.0,0.5,1.0);
	double vel_y = gauss(2.0,0.5,1.0);
	Vector3d col = Vector3d(gauss(0.5,0.5,1.0),gauss(0.5,0.5,1.0),gauss(0.5,0.5,1.0));
	for(int i = 0; i < count; i++){
		Vector3d pos = Vector3d(r*cos(angle),-2.0,r*sin(angle));
		Vector3d vel = Vector3d(vel_scalar*cos(angle),vel_y,vel_scalar*sin(angle));
		Vector3d acc = Vector3d(0.0,-0.5,0.0);
		//rate,count,particle life,emitter life
		emitters.push_back(new SimpleEmitter(pos,vel,acc,col,200,800,1.0,4.0,30*2*PI/360,0.3));
		emitters[i] -> set_rotate(rotate);
		emitters[i] -> set_current_time(start_time);
		start_time += time_interval;
		angle += angle_factor;
	}
}

void PlateGenerator::Update(double timestep) {
	if(state == ALIVE){
		for(int i = 0;i < emitters.size(); i++){
			//std::cout<<"emitter["<<i<<"]:"<<std::endl;
			if(emitters[count-1] -> state == DEAD){
				state = DEAD;
				return;
			}
			emitters[i]->Update(timestep);
		}
	}
}

void PlateGenerator::Draw() {
	if(state == ALIVE){
		for(int i = 0; i < emitters.size(); ++i) {
			emitters[i]->Draw();
		}
	}	
}


/************ExplosionGenerator***********/

ExplosionGenerator::ExplosionGenerator(double r, bool rotate): 
Generator(),
radius(r),
rot(rotate),
count(1){
	Vector3d pos = Vector3d(gauss(0,r,1.0),0,gauss(0,r,1.0));
	Vector3d vel = Vector3d(gauss(0,0.3,1.0),2.0,gauss(0,0.3,1.0));
	Vector3d col = Vector3d(gauss(0.5,0.5,1.0),gauss(0.5,0.5,1.0),gauss(0.5,0.5,1.0));	
	Vector3d acc = Vector3d(0.0,-0.2,0.0);
	//rate,count,particle life,emitter life
	emitters.push_back(new SimpleEmitter(pos,vel,acc,col,200,800,1.0,4.0,30*2*PI/360,0.3));
	emitters[0] -> set_rotate(rot);
	emitters[0] -> set_current_time(0);
}


void ExplosionGenerator::Update(double timestep) {
	if(state == ALIVE) {
		if(count == 1) {
			if(emitters[0] -> state == DEAD) {
				count = floor(gauss(50,10,1.0));
				Vector3d col = emitters[0] -> start_color;
				Vector3d pos = emitters[0] -> start_position;
				Vector3d acc = Vector3d(0.0,-0.2,0.0);
				for(int i = 0; i < count; i++) {				
					Vector3d vel = Vector3d(gauss(0,0.5,1.0),gauss(0,0.5,1.0),gauss(0,0.5,1.0));						
					emitters.push_back(new SimpleEmitter(pos,vel,acc,col,200,800,2.0,6.0,50*2*PI/360,0.1));
					emitters[i] -> set_rotate(rot);
				}
			}else {
				emitters[0] -> Update(timestep);
			}
		}else{
			vector<SimpleEmitter*>::iterator it = emitters.begin();
				while( it != emitters.end() ) {
					if( (*it) -> state == DEAD ) {
						it = emitters.erase(it);
					}
					else {
						it++;
					}
					(*it) -> Update(timestep); 
				}
				if(emitters.size() == 1) {
					state = DEAD;
				}
			}			
	}	
}


void ExplosionGenerator::Draw() {
	if(state == ALIVE){
		for(int i = 0; i < emitters.size(); i++) {
			emitters[i] -> Draw();
		}
	}	
}