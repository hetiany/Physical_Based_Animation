 #include "Emitter.h"
#include "gauss.h"
#include <math.h>
#include <GL/glut.h>

using namespace std;

/*****SimpleEmitter*****/
void SimpleEmitter::GenerateParticles(double ts) {

	const size_t maxNewParticles = static_cast<size_t>(ts * emit_rate);
	const size_t start = particles -> p_countAlive;
	const size_t end = min(start + maxNewParticles, particles -> p_count - 1);

	for(int i = start; i < end; i++){
		double Thita = gauss(0, PI/3, 1);
		double Phy = sqrt( fabs(gauss(0.5,0.5,1)) ) * offset_angle;

		//cout << "Thita " << Thita << ' ' << "Phy " << Phy << endl;

		double Vxx = vel_scalar * sin(Phy) * cos(Thita);// + gauss(0,0.1,1);
		double Vyy = vel_scalar * cos(Phy);// + gauss(0,0.1,1);
		double Vzz = vel_scalar * sin(Phy) * sin(Thita);// + gauss(0,0.1,1);

		//cout << "Vxx " << Vxx << "Vyy " << Vyy << "Vzz " << Vzz << endl;

		double Vx = M[0].x * Vxx + M[1].x * Vyy + M[2].x * Vzz;
		double Vy = M[0].y * Vxx + M[1].y * Vyy + M[2].y * Vzz;
		double Vz = M[0].z * Vxx + M[1].z * Vyy + M[2].z * Vzz;

        particles -> wake(i);
        particles -> p_pos[i] = start_position;
		particles -> p_vel[i] = Vector3d(Vx,Vy,Vz);
		particles -> p_acc[i] = start_acc;
		particles -> p_time[i] = gauss(0,0.3, 1.0);
	}
}


double Thita_temp = 0.0;
void SimpleEmitter::Update(double timeStep) {
	
	current_life += timeStep;
	if(current_life > 0 && current_life < 0.8 * total_life) {
		state = ALIVE;
	} 
	else if(current_life > 0.8 * total_life && current_life < total_life) {
		state = OLD;
	}
	else if(current_life > total_life) {
		state = DEAD;
	}

	switch(state){
		case WAIT:
			return;
		case ALIVE:
			break;
		case OLD:
			alpha = 5.0 - 5.0 * current_life/total_life;
			break;
		case DEAD:
			return;
		default:
			break;
	}

	start_position = start_position + start_velocity * timeStep;
	start_velocity = start_velocity + start_acc * timeStep;


	/***************rotation firework*************/
	if( rotate) {
		Vector3d M_temp[3];
		Vector3d a_temp;
		if( start_velocity.y == 0 && start_velocity.z == 0 )
			a_temp = Vector3d(0.0,1.0,0.0);
		else
			a_temp = Vector3d(1.0,0.0,0.0);
		Vector3d Uz_temp = (a_temp % -start_velocity) / (a_temp % -start_velocity).norm();
		Vector3d Ux_temp = -start_velocity % Uz_temp;
		M_temp[0] = Ux_temp;
		M_temp[1] = -start_velocity;
		M_temp[2] = Uz_temp;


		//double Thita_temp = gauss(0,PI/3,1);
		Thita_temp += 3.14/180;
		//Thita_temp += 3.14/250;
		//double Phy_temp = sqrt( fabs(gauss(2.5,0.3,1)) ) * 2.5;

		double Phy_temp = 2.5;
		//double Phy_temp = 2.5;

		//cout << "Thita " << Thita << ' ' << "Phy " << Phy << endl;
		//double vel_scalar_temp = 1.3;
		double vel_scalar_temp = 1.7;
		double Vxx = vel_scalar_temp * sin(Phy_temp) * cos(Thita_temp);// + gauss(0,0.1,1);
		double Vyy = vel_scalar_temp * cos(Phy_temp);// + gauss(0,0.1,1);
		double Vzz = vel_scalar_temp * sin(Phy_temp) * sin(Thita_temp);// + gauss(0,0.1,1);


		double Vx = M_temp[0].x * Vxx + M_temp[1].x * Vyy + M_temp[2].x * Vzz;
		double Vy = M_temp[0].y * Vxx + M_temp[1].y * Vyy + M_temp[2].y * Vzz;
		double Vz = M_temp[0].z * Vxx + M_temp[1].z * Vyy + M_temp[2].z * Vzz;


		Vector3d direction_normal(Vx, Vy, Vz);
		Vector3d a;
		if( direction_normal.y == 0 && direction_normal.z == 0 )
			a = Vector3d(0.0,1.0,0.0);
		else
			a = Vector3d(1.0,0.0,0.0);
		Vector3d Uz = (a % direction_normal) / (a % direction_normal).norm();
		Vector3d Ux = direction_normal % Uz;
		M[0] = Ux;
		M[1] = direction_normal;
		M[2] = Uz;
	}
	
	if(!rotate) {
		  Vector3d a;
		if( start_velocity.y == 0 && start_velocity.z == 0 )
			a = Vector3d(0.0,1.0,0.0);
		else
			a = Vector3d(1.0,0.0,0.0);
		Vector3d Uz = (a % -start_velocity) / (a % -start_velocity).norm();
		Vector3d Ux = -start_velocity % Uz;
		M[0] = Ux;
		M[1] = -start_velocity;
		M[2] = Uz;

	}
  
	const unsigned int end = particles -> p_countAlive;

	for(int i = 0; i < end; i++){
		particles -> p_time[i] += timeStep;
		particles -> p_pos[i] = particles -> p_pos[i] + particles -> p_vel[i] * timeStep;
		particles -> p_vel[i] = particles -> p_vel[i] + start_acc * timeStep;

		if(particles -> p_time[i] > particle_life_time){
			particles -> kill(i);
		}
	}
	GenerateParticles(timeStep);

}


void SimpleEmitter::Draw() {
	if(state == ALIVE || state == OLD){
		const unsigned int end = particles -> p_countAlive;
	   	glPointSize(1.0);
	   	glDisable(GL_DEPTH_TEST);
	   	glEnable(GL_BLEND);
	    glBegin(GL_POINTS);
	    {
	    	for(int i = 0; i < end; i++){
	    		glColor4f(start_color.x,start_color.y,start_color.z, alpha);
	        	glVertex3f(particles -> p_pos[i].x, particles -> p_pos[i].y, particles -> p_pos[i].z);
	    	}
	    }
	    glEnd();
	    glDisable(GL_BLEND);
	    glEnable(GL_DEPTH_TEST);
	}
}

