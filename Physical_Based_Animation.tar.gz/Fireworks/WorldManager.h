#ifndef WORLDMANAGER_H
#define WORLDMANAGER_H
#include "Generator.h"
//#include "Obstacle.h"
#include "Vector.h"
#include <vector> 

class WorldManager{

public:
	WorldManager():
	generators(),
	exp_generators() {

	}
	
	~WorldManager() {

	}

	void Add_PlateGenerator(PlateGenerator* plate_gen);
	void Add_ExplosionGenerator(ExplosionGenerator* explosion_gen);
	void Update(double timeStep);
	void Draw();

	double interval;


private:
	double floor_height;
	std::vector<Generator*> generators;
	std::vector<Generator*> exp_generators; 	
};


#endif