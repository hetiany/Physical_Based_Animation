#include <GL/glut.h>
#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include "WorldManager.h"
#include "Camera.h"
#include "gauss.h"


Camera *camera;
int WIDTH = 960;
int HEIGHT = 640;


static double timeStep = 0.05;		//Timestep


//Plate generator parameter
double radius = 8.0;
double time_inv = 0.5;
double rotate_angle = 0.0;
double emitter_count = 0.0;

//Explosion generator parameter
double interval = 2.0;
double explode_count = 11.0;
double explode_emitter = 6.0;

WorldManager manager;

struct point{
	float x,y,z;
};

void do_viewvolume() {
struct point eye, view, up;

// specify size and shape of view volume
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluPerspective(45.0,1.0,0.1,40.0);

//specify position for view volume
glMatrixMode(GL_MODELVIEW);
glLoadIdentity();

eye.x=6.0; eye.y=5.0; eye.z=4.0;
view.x=0.0;view.y=0.0;view.z=0.0;
up.x=0.0;up.y=1.0;up.z=0.0;

gluLookAt(eye.x,eye.y,eye.z,view.x,view.y,view.z,up.x,up.y,up.z);

camera = new Camera(Vector3d(eye.x,eye.y,eye.z), Vector3d(view.x,view.y,view.z), 
		      Vector3d(up.x,up.y,up.z));

}

void Draw() {

	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	//gray background
	glClearColor(0.0,0.0,0.0,0.0);
	camera->PerspectiveDisplay(WIDTH,HEIGHT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	manager.Draw();
  glAccum(GL_MULT, 0.6);
  glAccum(GL_ACCUM, 1.0);
  glAccum(GL_RETURN, 1.0);
  glFlush();
	glutSwapBuffers();
}

void update(int value) {
	manager.Update(timeStep);
	glutPostRedisplay();
	glutTimerFunc(timeStep*100, update, 1);
}

void mouseEventHandler(int button, int state, int x, int y) {
  // let the camera handle some specific mouse events (similar to maya)
  camera->HandleMouseEvent(button, state, x, y);
  glutPostRedisplay();
}

void motionEventHandler(int x, int y) {
  // let the camera handle some mouse motions if the camera is to be moved
  camera->HandleMouseMotion(x, y);
  glutPostRedisplay();
}

void handleKey(unsigned char key, int x, int y){
  
  switch(key){
  	case 'a':
  		manager.Add_PlateGenerator(new PlateGenerator(gauss(6.0,2.0,1.0),floor(gauss(15,3,1.0)), 0 ));
  		//manager.Add_PlateGenerator(new PlateGenerator(gauss(6.0,2.0,1.0),gauss(15,3,1.0) ) );
  		break;
  	case 's':
  		manager.Add_PlateGenerator(new PlateGenerator(gauss(6.0,2.0,1.0),floor(gauss(15,3,1.0)), 1));
  		break;
  	case 'd':
  		manager.Add_ExplosionGenerator(new ExplosionGenerator(2.0, 0) );
  		break;		
  	case 'f':
  		manager.Add_ExplosionGenerator(new ExplosionGenerator(2.0, 1) );
  		break;	
  	case 'g':
  		manager.Add_PlateGenerator(new PlateGenerator(gauss(6.0,2.0,1.0),floor(gauss(15,3,1.0)), 0 ));
  		manager.Add_PlateGenerator(new PlateGenerator(gauss(6.0,2.0,1.0),floor(gauss(15,3,1.0)), 1));
  		manager.Add_ExplosionGenerator(new ExplosionGenerator(2.0, 0) );
  		manager.Add_ExplosionGenerator(new ExplosionGenerator(2.0, 1) );
  		break;
    case 'q':		// q - quit
    case 27:		// esc - quit
      exit(0);
    default:		// not a valid key -- just ignore it
      return;
  }
}


int main(int argc, char* argv[]) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
	glutInitWindowSize(WIDTH,HEIGHT);
	glutInitWindowPosition(200, 200);
	glutCreateWindow("Final Fireworks");
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);

  glClear(GL_ACCUM_BUFFER_BIT);
	
  do_viewvolume();
	glutDisplayFunc(Draw);
	glutTimerFunc(timeStep*1000, update, 1);
	glutMouseFunc(mouseEventHandler);
  glutMotionFunc(motionEventHandler);
	glutKeyboardFunc(handleKey);
	glutMainLoop();
	return 0;
}
