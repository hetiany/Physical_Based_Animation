#include "ParticleData.h"


void ParticleData::generate(size_t maxSize) {
    p_count = maxSize;
    p_countAlive = 0;

    p_pos = new Vector3d[maxSize];
    p_vel = new Vector3d[maxSize];
    p_alive = new bool[maxSize];
    p_acc = new Vector3d[maxSize];
    p_time = new double[maxSize];
}

void ParticleData::kill(size_t id) {
	if (p_countAlive > 0) {
		p_alive[id] = false;
		swapData(id, p_countAlive - 1);
		--p_countAlive;
	}
}

void ParticleData::wake(size_t id) {
	if (p_countAlive < p_count) {
		p_alive[id] = true;
		swapData(id, p_countAlive);
		++p_countAlive;
	}
}

void ParticleData::swapData(size_t a, size_t b) {

	swap(p_pos[a], p_pos[b]);
	swap(p_vel[a], p_vel[b]);
	swap(p_acc[a], p_acc[b]);
	swap(p_time[a],p_time[b]);
	swap(p_alive[a], p_alive[b]);
}