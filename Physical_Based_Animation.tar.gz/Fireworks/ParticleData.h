#ifndef PARTICLEDATA_H
#define PARTICLEDATA_H

#include <memory>
#include "Vector.h"

using namespace std;

class ParticleData {
public:
	ParticleData(size_t maxCount) { 
		generate(maxCount); 
	}

	~ParticleData() {		
		delete [] p_pos;
		delete [] p_vel;
		delete [] p_acc;
		delete [] p_alive;
		delete [] p_time;
	}

	void generate(size_t maxSize);
	void kill(size_t id);
	void wake(size_t id);
	void swapData(size_t a, size_t b);


	Vector3d* p_pos;
	Vector3d* p_vel;
	Vector3d* p_acc;

	double* p_time;
	bool* p_alive;
	size_t p_count;
	size_t p_countAlive;
};


#endif