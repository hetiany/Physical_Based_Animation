#ifndef GENERATOR_H
#define GENERATOR_H
#include <GL/glut.h>
#include "ParticleData.h"
#include "Vector.h"
#include <vector>
#include "Emitter.h"

using namespace std;

class Generator {
public:
	Generator():state(ALIVE){}
	~Generator(){};
	virtual void Update(double timeStep) = 0;
	virtual void Draw() = 0;

	int state;
};


class PlateGenerator : public Generator {
public:
	PlateGenerator(double r,int Count, bool rotate);
	~PlateGenerator(){
		for(int i = 0; i < emitters.size(); ++i) {
			delete emitters[i];
		}
	}
	void Update(double timeStep);
	void Draw();

private:
	double radius;
	int count;
	vector<SimpleEmitter*> emitters;
};



class ExplosionGenerator : public Generator {
public:
	ExplosionGenerator(double r, bool rotate);
	~ExplosionGenerator(){
		for(int i = 0; i < emitters.size(); ++i) {
			delete emitters[i];
		}
	}

	bool rot;
	void Update(double timeStep);
	void Draw();

private:
	double radius;
	int count;
	vector<SimpleEmitter*> emitters;
};
#endif
