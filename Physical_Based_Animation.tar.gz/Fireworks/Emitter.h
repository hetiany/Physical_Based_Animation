#ifndef EMITTER_H
#define GENERATOR_H
#include <GL/glut.h>
#include "ParticleData.h"
#include "Vector.h"

#define WAIT 0 
#define ALIVE 1
#define OLD 2 
#define DEAD 3
using namespace std;


class Emitter {
public:
	Emitter(Vector3d pos, Vector3d vel, Vector3d acc,Vector3d color, 
		    double rate, double p_count, double particle_life, double emitter_life): 
	start_position(pos), 
	start_velocity(vel), 
	start_acc(acc),
	start_color(color),
	direction_normal(0.0, 0.0, 0.0),
	emit_rate(rate),
	particle_life_time(particle_life),
	total_life(emitter_life),
	current_life(0),
	alpha(1.0),
	state(WAIT){
		particles = new ParticleData(p_count);
		for(int i = 0; i < p_count; ++i) {
			particles -> p_alive[i] = false;
		}
	} 

	Vector3d start_position;
	Vector3d start_velocity;
	Vector3d start_acc;
	Vector3d start_color;

	Vector3d direction_normal;

	double emit_rate;
	double particle_life_time;
	double total_life;
	double current_life;
	double alpha;
	int state;

	ParticleData* particles;

	virtual void GenerateParticles(double ts) = 0;
	virtual void Update(double timeStep) = 0;
	virtual void Draw() = 0;
	virtual ~Emitter() { delete particles;}

}; 


/**SimpleEmitter**/
class SimpleEmitter: public Emitter{
public:
	SimpleEmitter(Vector3d pos, Vector3d vel, Vector3d acc, Vector3d color, 
		            double rate, double p_count, double particle_life, 
		            double emitter_life,double angle, double scalar):	
	Emitter(pos, vel, acc, color,rate, p_count, particle_life, emitter_life),
	offset_angle(angle),
	vel_scalar(scalar),
	rotate(0.0) {

	}

	void set_rotate(bool rot) {
		rotate = rot;
	}

    void GenerateParticles(double dt);
	void Update(double timeStep);
	void Draw();
	void set_current_time(double life){ current_life = life;}

private:
	double start_time;
	double offset_angle;
	double vel_scalar;
	Vector3d M[3];

	bool rotate;
	
};

#endif